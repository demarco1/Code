# LigminchaGlobal extension

## Unifies the Joomlas and other web-apps in the Ligmincha International system

See [Ligmincha International Wiki](http://wiki.ligmincha.org/LigminchaGlobal_extension) for details.
